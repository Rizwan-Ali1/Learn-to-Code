# Learn-to-Code2023
This repository made for Hacktoberfest.
you can contribute to this repo
it takes only 2 minutes 
